var cart = [];

var itemData = {
    1: {
        name: "14k Gold Cross Necklace with Diamonds",
        price: 170000
    },
    2: {
        name: "14k Gold Sweet Droplet Diamond Necklace",
        price: 180000
    },
    3: {
        name: "Sparkling infinity Collier Necklace",
        price: 67000
    },
    4: {
        name: "Wild Flower Multi Diamond Necklace",
        price: 55000
    },
    5: {
        name: "Chloe Gold Pendant Necklace",
        price: 71000
    },
    6: {
        name: "Elisa Gold Pendant Necklace in Ivory Pearl",
        price: 200000
    },
    7: {
        name: "Midi Hoop Earrings",
        price: 174500
    },
    8: {
        name: "Gold Annoushka Pearl Earrings",
        price: 63500
    },
    9: {
        name: "Gold Stud Earrings",
        price: 73300
    },
    10: {
        name: "Judith Ripka 14k Selvaggia Drop Earrings With Diamond",
        price: 69000
    },
    11: {
        name: "14k Yellow and White gold Two-tone Marquis Cage Earrings",
        price: 130700
    },
    12: {
        name: "Serpentino 18k Gold Vermeil Tubogas Hoop Earrings",
        price: 330000
    },
    13: {
        name: "1Carat Princess Cut Moissanite Engagement Ring",
        price: 170000
    },
    14: {
        name: "Beguilling 22 Karat Gold Artsy Ring",
        price: 78000
    },
    15: {
        name: "Diamond Semi-Mount Ring",
        price: 75000
    },
    16: {
        name: "Double Heart Sparkling Ring",
        price: 190000
    },
    17: {
        name: "Oval Cut Solitaire Ring",
        price: 75000
    },
    18: {
        name: "Single Diamond Rose Gold Ring",
        price: 85000
    },
    19: {
        name: "Bead Bracelet in Sterling Silver",
        price: 39000
    },
    20: {
        name: "Mini Diamond Tennis Bracelet",
        price: 80000
    },
    21: {
        name: "Cartier Yellow Gold LOVE Bracelet",
        price: 75000
    },
    22: {
        name: "Core Essentials Two-tone Stainless Steel Id Bracelet",
        price: 90600
    },
    23: {
        name: "Diamond Sideways Large Infinity Bracelet 14k Rose Gold",
        price: 175000
    },
    24: {
        name: "Bracelet Rose Gold",
        price: 185000
    },
};


var itemNames = {
    1: "14k Gold Cross Necklace with Diamonds",
    2: "14k Gold Sweet Droplet Diamond Necklace",
    3: "Sparkling infinity Collier Necklace",
    4: "Wild Flower Multi Diamond Necklace",
    5: "Chloe Gold Pendant Necklace",
    6: "Elisa Gold Pendant Necklace in Ivory Pearl",
    7: "Midi Hoop Earrings",
    8: "Gold Annoushka Pearl Earrings",
    9: "Gold Stud Earrings",
    10: "Judith Ripka 14k Selvaggia Drop Earrings With Diamond",
    11: "14k Yellow and White gold Two-tone Marquis Cage Earrings",
    12: "Serpentino 18k Gold Vermeil Tubogas Hoop Earrings",
    13: "1Carat Princess Cut Moissanite Engagement Ring",
    14: "Beguilling 22 Karat Gold Artsy Ring",
    15: "Diamond Semi-Mount Ring",
    16: "Double Heart Sparkling Ring",
    17: "Oval Cut Solitaire Ring",
    18: "Single Diamond Rose Gold Ring",
    19: "Bead Bracelet in Sterling Silver",
    20: "Mini Diamond Tennis Bracelet",
    21: "Cartier Yellow Gold LOVE Bracelet",
    22: "Core Essentials Two-tone Stainless Steel Id Bracelet",
    23: "Diamond Sideways Large Infinity Bracelet 14k Rose Gold",
    24: "Bracelet Rose Gold"
};


function switchTab(tabId) {
    var tabs = document.querySelectorAll('.nav-link');
    tabs.forEach(function (tab) {
        tab.classList.remove('active'); 
    });

    var selectedTab = document.querySelector('#' + tabId + '-tab');
    selectedTab.classList.add('active'); 

    
    var tabTrigger = new bootstrap.Tab(selectedTab);
    tabTrigger.show();
}


document.querySelectorAll('.nav-link').forEach(function (tab) {
    tab.addEventListener('click', function () {
        switchTab(this.getAttribute('aria-controls'));
    });
});


var cart = [];

// "Add to Cart" button click event handler
document.querySelectorAll(".addToCart").forEach(function (button) {
    button.addEventListener("click", function () {
        var quantityInput = button.parentElement.previousElementSibling; // Get the quantity input field
        var quantity = parseInt(quantityInput.value);

        if (quantity > 0) {
            // Get item details from data attributes
            var itemId = button.getAttribute("data-item-id");
            var itemName = itemNames[itemId];
            var itemPrice = parseFloat(button.getAttribute("data-item-price"));

            // Check if the item is already in the cart
            var existingItem = cart.find(item => item.id === itemId);

            if (existingItem) {
                // If the item is already in the cart, update its quantity
                existingItem.quantity += quantity;
            } else {
                // If the item is not in the cart, add it as a new item
                var itemData = {
                    id: itemId,
                    name: itemName,
                    price: itemPrice,
                    quantity: quantity
                };
                cart.push(itemData);
            }

            // Reset the quantity input field to 0
            quantityInput.value = 0;

            // Update the cart items list in the UI
            updateCartItems();

            // Hide the "cart is empty" message
            hideCartEmptyMessage();
        } else {
            // Display an error message if the quantity is not valid
            alert("Please enter a valid quantity (greater than 0).");
        }
    });
});


function hideCartEmptyMessage() {
    var emptyCartMessage = document.getElementById("empty-cart-message");
    if (cart.length > 0) {
        emptyCartMessage.style.display = "none";
    } else {
        emptyCartMessage.style.display = "block";
    }
}

// Function to update the cart items list in the UI
function updateCartItems() {
    var cartItemsList = document.getElementById("cart-items");
    var totalElement = document.getElementById("total-price");

    cartItemsList.innerHTML = ''; // Clear the cart items list

    // Iterate through the cart and display items
    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        var listItem = document.createElement("li");
        var itemTotalPrice = item.price * item.quantity;
        listItem.textContent = item.name + " x " + item.quantity + " - " + itemTotalPrice.toFixed(2) + "B";
        cartItemsList.appendChild(listItem);
    }

    // Calculate and display the total price
    var total = calculateTotal();
    totalElement.textContent = total.toFixed(2);
}




// Function to calculate the total price of items in the cart
function calculateTotal() {
    var total = 0;
    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        total += item.price * item.quantity;
    }
    return total;
}



function clearCart() {
    cart = []; 
    updateCartItems(); 
    updateModalTotal(); 
}


var clearCartButton = document.getElementById("clear-cart-btn");
clearCartButton.addEventListener("click", clearCart);


function displayCartSummary() {
    var cartSummary = document.querySelector("#checkoutModal .modal-body");

    
    if (cart.length > 0) {
        var cartItemsList = document.createElement("ul");
        cartItemsList.classList.add("list-group");

        for (var i = 0; i < cart.length; i++) {
            var item = cart[i];
            var listItem = document.createElement("li");
            listItem.classList.add("list-group-item");
            listItem.textContent = "Item " + item.id + " x " + item.quantity;
            cartItemsList.appendChild(listItem);
        }

        
        cartSummary.innerHTML = "";
        cartSummary.appendChild(cartItemsList);
    }
}



function displayCartItemsInModal() {
    var cartItemContainer = document.getElementById("cart-item-list");
    cartItemContainer.innerHTML = ""; 

    
    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        var listItem = document.createElement("li");
        listItem.textContent = itemNames[item.id] + " x " + item.quantity;
        cartItemContainer.appendChild(listItem);
    }
}


var placeOrderButton = document.getElementById("place-order-btn");
placeOrderButton.addEventListener("click", function () {
    
    alert("Order placed successfully!");

    
    location.reload();
});

function calculateTotal() {
    var total = 0;
    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        var itemInfo = itemData[item.id]; 
        total += itemInfo.price * item.quantity; 
    }
    return total;
}

document.addEventListener("DOMContentLoaded", function () {
    
    var checkoutButton = document.getElementById("checkout-btn");

    
    checkoutButton.addEventListener("click", function () {
        if (cart.length > 0) {

            
            var checkoutModal = new bootstrap.Modal(document.getElementById("checkoutModal"));
            checkoutModal.show();

            
            updateModalTotal();

            
            displayCartItemsInModal();

            
            var totalElement = document.getElementById("modal-total-price");
            var total = calculateTotal();
            totalElement.textContent = total.toFixed(2) + "B"; 

           
            placeOrderButton.disabled = false;
        } else {
            
            alert("Your cart is empty. Add items to your cart before checking out.");
        }
    });
});



function updateModalTotal() {
    var modalTotalElement = document.getElementById("modal-total-price");
    var total = calculateTotal();
    modalTotalElement.textContent = "$" + total.toFixed(2);
}

var element = document.getElementById("your-element-id");
if (element !== null) {
    
    element.addEventListener("click", function () {
        
    });
}

var closeModalButton = document.getElementById("closeModalButton"); 

if (closeModalButton) {
    closeModalButton.addEventListener("click", function () {
        
    });
}

$(document).ready(function () {
    
    $('a.nav-link').click(function (e) {
        e.preventDefault(); 

        
        var targetTab = $(this).attr('href');

        
        $('.tab-pane').removeClass('show active'); 
        $(targetTab).addClass('show active'); 
    });
});



$(document).ready(function () {
    
    $('#checkoutModal').on('hidden.bs.modal', function () {
        
        $('#cart-item-list').empty(); 
        $('#modal-total-price').text('0.00B'); 
    });
});